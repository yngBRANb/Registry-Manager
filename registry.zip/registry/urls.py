from django.contrib import admin
from django.urls import path, include
from web.views import *
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index, name='index'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('error-page/', errorPage, name='error'),
]
