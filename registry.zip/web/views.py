from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.shortcuts import redirect
from .models import *


def login_view(request):
    return render(request, 'login.html')  # Render the login form if GET request

def index(request):
    return render(request, 'index.html')

def errorPage(request):
    return render(request, 'error.html')